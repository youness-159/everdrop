import{f as r}from"./shopAPI-BOLETFd3.js";const e=async()=>await r("/orders"),s=async()=>await r("/orders/length"),a=async()=>await r("/orders/my-orders");export{s as a,a as b,e as g};
