import{f as t,p as r,d as s}from"./shopAPI-BOLETFd3.js";const c=async()=>await t("/carts/my-cart"),n=async a=>await r("/carts",a),o=async a=>await s(`/carts/${a}`);export{n as a,o as d,c as g};
